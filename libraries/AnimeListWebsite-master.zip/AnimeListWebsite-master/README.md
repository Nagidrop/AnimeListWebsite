# AnimeListWebsite Project

This project aims to develop a website using Java. It will have similar functionalities compared to MyAnimeList.com (a.k.a MAL - which is also used as a template/reference to design) but with only limited core functions, such as view, search, add animes to list or favourites. 

> Basic functions where users can log in, register and view their profiles are as well included. 

> This is used as an assignment project in university.


*Written in Java, with MVC 2 architecture, Struts 2 Framework on NetBeans IDE 8.2.*


Contributors: Wibu Group. The group consists of:

```
Nguyễn Đức Tông (Leader)
Quản Đức Lộc (Member)
Trần Minh Thắng (Member)
Lưu Tiến Minh (Member)
```
